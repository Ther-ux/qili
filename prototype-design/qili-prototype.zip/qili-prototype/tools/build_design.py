"""Qili prototype source. Native shapes are authored through Evolus Pencil's MCP API."""
from pathlib import Path
import json, html, sys, copy

ROOT=Path(__file__).resolve().parents[1]
BG='#F6F7F3'; WHITE='#FFFFFF'; INK='#203C36'; GREEN='#245C4D'; MUTE='#75827C'; LINE='#E2E8E0'; SOFT='#EAF0E7'; RED='#B9503E'; AMBER='#986B2D'; CREAM='#F3E7D1'
PAGES=[]

class Page:
    def __init__(self,key,title,section='用户端',w=1440,h=960,note='',rules=''):
        self.key=key;self.title=title;self.section=section;self.w=w;self.h=h;self.note=note;self.rules=rules;self.nodes=[];self.links=[];self.fields=[]
        PAGES.append(self)
        self.box(0,0,w,h,BG,r=0)
    def box(self,x,y,w,h,fill=WHITE,stroke=None,r=14,text='',size=15,color=INK,bold=False,align='left',kind='rect',target=None,label=None):
        n=dict(x=x,y=y,w=w,h=h,fill=fill,stroke=stroke or 'none',r=r,text=text,size=size,color=color,bold=bold,align=align,kind=kind)
        self.nodes.append(n)
        if target:self.link(x,y,w,h,target,label or text)
        return n
    def text(self,x,y,text,size=15,color=INK,bold=False,w=1100,h=None):
        return self.box(x,y,w,h or round(size*1.65),fill='none',r=0,text=text,size=size,color=color,bold=bold)
    def link(self,x,y,w,h,target,label): self.links.append(dict(x=x,y=y,w=w,h=h,target=target,label=label))
    def btn(self,x,y,text,target,w=160,style='primary'):
        self.box(x,y,w,44,GREEN if style=='primary' else WHITE,LINE if style!='primary' else None,10,text,14,WHITE if style=='primary' else GREEN,True,'center',target=target)
    def pill(self,x,y,text,fill=SOFT,color=GREEN,w=None):
        self.box(x,y,w or max(60,len(text)*13+22),28,fill,r=14,text=text,size=12,color=color,align='center')
    def card(self,x,y,w,h):self.box(x,y,w,h,WHITE,LINE,16)
    def field(self,x,y,w,text,name='',kind='text'):
        self.box(x,y,w,46,WHITE,LINE,9,text='  '+text,size=14,color=MUTE)
        self.fields.append(dict(x=x+10,y=y+2,w=w-20,h=42,name=name or text,placeholder=text,kind=kind))
    def shell(self,active='学习总览',admin=False):
        self.box(0,0,228,self.h,WHITE,r=0);self.box(227,0,1,self.h,LINE,r=0)
        self.box(28,30,42,42,GREEN,r=12,text='棋',size=24,color=WHITE,bold=True,align='center')
        self.text(82,28,'棋理学伴',21,bold=True,w=138);self.text(83,58,'QILI  /  '+('管理工作台' if admin else '每一步，都有道理'),10,MUTE,w=143)
        nav=([('工作台','admin'),('题库管理','puzzles-admin'),('规则知识','knowledge'),('Agent 运行','logs')] if admin else [('学习总览','home'),('练习题库','library'),('导入残局','import'),('我的错题','mistakes'),('专属教练','profile')])
        for i,(label,target) in enumerate(nav):
            yy=132+i*58
            self.box(20,yy,188,44,SOFT if label==active else WHITE,r=10)
            self.text(38,yy+8,['◈','▦','⊞','◷','✧'][i],19,GREEN if label==active else MUTE,w=25)
            self.text(74,yy+10,label,15,GREEN if label==active else MUTE,label==active,w=130)
            self.link(20,yy,188,44,target,label)
        self.box(20,self.h-170,188,92,BG,r=12)
        self.text(35,self.h-155,'先想一想，再走一步',14,bold=True,w=165)
        self.text(35,self.h-126,'把棋理变成自己的本领。',12,MUTE,w=164)
        self.text(30,self.h-50,'↗ '+('返回学习端' if admin else '内容管理'),12,MUTE,w=180)
        self.link(20,self.h-60,188,40,'home' if admin else 'admin','切换工作台')
        self.text(266,29,('内容与教学 / '+active) if admin else '我的学习空间 / '+active,13,MUTE,w=600)
        self.text(1105,29,'● 本地学习记录',12,MUTE,w=150)
        self.box(1283,20,118,36,WHITE,LINE,18,text='⚙ API 设置',size=12,color=GREEN,align='center',target='settings')
        self.box(228,76,1212,1,LINE,r=0)
    def head(self,kicker,title,desc='',action=None):
        self.text(270,104,kicker,11,GREEN,True)
        self.text(270,130,title,29,bold=True)
        if desc:self.text(271,180,desc,14,MUTE)
        if action:self.btn(1222,139,action[0],action[1],176)

def board(p,x,y,w=500,selected=False,done=False,hint=False,mini=False,mode='train'):
    cell=w/10; xx=x+cell; yy=y+cell*.78
    p.box(x,y,w,w*1.095,CREAM,'#DCCBAD',14)
    # Native primitives keep every grid line, coordinate and piece editable.
    for row in range(10):p.box(xx,yy+row*cell,8*cell,1,'#BAA785',r=0)
    for col in range(9):
        p.box(xx+col*cell,yy,1,4*cell,'#BAA785',r=0)
        p.box(xx+col*cell,yy+5*cell,1,4*cell,'#BAA785',r=0)
    p.text(xx+cell*.8,yy+4.18*cell,'楚  河',int(cell*.29),'#9C8767',w=3*cell)
    p.text(xx+cell*5.2,yy+4.18*cell,'汉  界',int(cell*.29),'#9C8767',w=3*cell)
    # Palace diagonal vectors are also editable Pencil line stencils.
    for base in [0,7]:
        for a,b,c,d in [(3,base,5,base+2),(5,base,3,base+2)]:
            p.nodes.append(dict(kind='line',x=xx+a*cell,y=yy+b*cell,w=(c-a)*cell,h=(d-b)*cell,fill='#BAA785',stroke='none',r=0,text='',size=1,color=INK,bold=False,align='left'))
    pieces={'e9':('将',False),'e0':('帅',True),'e4':('兵',True),'b2':('炮',True),'b4':('车',True),'b7':('车',False)}
    if done:pieces.pop('b2');pieces['b7']=('炮',True)
    if mode=='study':pieces.pop('b2');pieces['c2']=('炮',True)
    if mode=='branch':pieces['d9']=pieces.pop('e9')
    if mode=='import':pieces={'d9':('将',False),'e0':('帅',True),'e7':('车',True)}
    for sq,(name,red) in pieces.items():
        col='abcdefghi'.index(sq[0]);row=9-int(sq[1]);cx=xx+col*cell;cy=yy+row*cell;r=cell*.39
        if selected and sq=='b2':p.box(cx-r-5,cy-r-5,r*2+10,r*2+10,'none',GREEN,99,kind='ellipse')
        p.box(cx-r,cy-r+2,r*2,r*2,'#D6C6AA',r=99,kind='ellipse')
        p.box(cx-r,cy-r,r*2,r*2,'#FFF8E9',RED if red else '#4F5148',99,name,int(cell*.45),RED if red else '#41483D',True,'center',kind='ellipse')
    if not mini:
        for i,c in enumerate('abcdefghi'):p.box(xx+(i-.5)*cell,yy+9.35*cell,cell,20,'none',r=0,text=c,size=11,color='#8D7858',align='center')
        for i in range(10):p.text(x+cell*.26,yy+i*cell-9,str(9-i),10,'#8D7858',w=20)
    if selected or hint:
        cx=xx+cell;cy=yy+2*cell
        p.box(cx-25,cy-25,50,50,'none',GREEN,99,kind='ellipse')
        p.box(cx-4,cy-4,8,8,'none',r=99,kind='ellipse')
    if mode=='train' and not mini and not done:
        # Each intersection is a target; only the scenario's correct one succeeds.
        for col in range(9):
            for row in range(10):
                sq='abcdefghi'[col]+str(9-row)
                target=('selected' if sq=='b2' else ('success' if sq=='b7' and selected else 'illegal' if selected else 'train'))
                p.link(xx+(col-.45)*cell,yy+(row-.45)*cell,cell*.9,cell*.9,target,'棋位 '+sq)
    return w*1.095

def coach_card(p,x,y,w=408,title='棋理教练',sub='先观察，再验证',body=None):
    p.card(x,y,w,138 if body else 82)
    p.box(x+18,y+18,40,40,SOFT,r=12,text='棋',size=22,color=GREEN,bold=True,align='center')
    p.text(x+72,y+17,title,17,bold=True,w=w-95);p.text(x+72,y+47,sub,12,MUTE,w=w-95)
    if body:p.text(x+20,y+89,body,14,w=w-36)

def training(key,title,state='initial',rules='R01 · R02 · R03'):
    desc={'initial':'先看目标，独立走一步。','selected':'已选择红炮 b2，请选择落点。','illegal':'路径隔子后的空点不能作为炮的落点。','hint1':'提示 1 / 3：先检查炮与目标之间的棋子。','hint2':'提示 2 / 3：b4 的红车就是唯一的炮架。','hint3':'提示 3 / 3：点击 b2 的红炮，再点击 b7 黑车。','success':'独立完成：规则已确认这一步达成目标。','assisted':'提示后完成：这次练习保留为辅助完成。'}[state]
    p=Page(key,title,note='点击棋子选择，再点落点。'+desc+' 可返回题库、重试或进入复盘。',rules=rules)
    p.shell('练习题库');p.head('基础训练  /  炮的走法','隔一子，才是炮',desc)
    p.btn(1238,137,'返回题库','library',160,'secondary')
    p.card(270,228,688,682);p.pill(294,248,'基础吃子');p.text(429,251,'红方走 · 第 02 / 20 题',13,MUTE,w=300)
    p.text(294,294,'目标：用红炮一步吃掉 b7 的黑车',17,bold=True,w=630)
    bdone=state in ['success','assisted']
    board(p,347,338,500,selected=state=='selected',done=bdone,hint=state=='hint3')
    p.text(983,231,'这一局，学会什么？',20,bold=True,w=410)
    coach_card(p,982,274,416,sub='规则核验已就绪 · AI 按需讲解')
    p.card(982,374,416,200)
    p.text(1006,395,'走棋前的小检查',15,bold=True,w=350)
    p.text(1006,432,'01   找到要移动的红炮',14,w=350)
    p.text(1006,470,'02   数一数中间的炮架',14,w=350)
    p.text(1006,508,'03   检查落点是否有敌子',14,w=350)
    fill=SOFT if bdone else '#FCF2E7' if state in ['illegal','hint1','hint2','hint3'] else WHITE
    p.box(982,594,416,123,fill,LINE,14)
    p.text(1006,610,'✓ '+('完成目标' if bdone else '这一步的反馈') if state!='illegal' else '这一步还不能走',16,GREEN if bdone else AMBER,True,w=360)
    lines=[desc[i:i+24] for i in range(0,len(desc),24)]
    for i,line in enumerate(lines):p.text(1006,647+i*24,line,13,MUTE,w=370)
    if bdone:
        p.btn(982,738,'和教练一起复盘','agent-wait',416)
        p.btn(982,796,'再独立练一次','train',200,'secondary');p.btn(1198,796,'查看本地解法','replay',200,'secondary')
    else:
        nxt={'hint1':'hint2','hint2':'hint3','hint3':'assisted'}.get(state,'hint1')
        p.btn(982,738,'完成这一步' if state=='hint3' else '给我一点提示',nxt,416,'secondary')
        p.btn(982,796,'重新尝试','train',200,'secondary');p.btn(1198,796,'查看本地解法','replay',200,'secondary')
    p.text(983,862,'提示和答案被查看后，本轮计为辅助完成。',12,MUTE,w=414)
    return p

def build():
    p=Page('guide','00 · 原型导览','设计说明',note='选择任一任务开始。所有统计、对话与运行状态均为原型演示数据。',rules='R00')
    p.box(0,0,1440,960,INK,r=0);p.pill(64,48,'QILI  /  PROTOTYPE',fill='#35584E',color='#EBEEE2',w=202)
    p.text(64,125,'棋理学伴',64,'#F6F2E8',True,w=1000,h=96)
    p.text(68,229,'每一步，都有道理。',26,'#C0CFC5',w=1000)
    p.text(68,294,'面向象棋初学者的短局面训练与个性化领域 Agent',18,'#C0CFC5')
    for x,num,title,desc,target in [(64,'01','自主练习','选题 → 走棋 → 分级提示 → 完成','home'),(500,'02','和教练复盘','表达想法 → 核验依据 → 对话 → 摆谱','report'),(936,'03','内容管理','题库维护 → 规则知识 → Agent 审查','admin')]:
        p.box(x,394,406,260,'#FAFBF6',r=18);p.text(x+26,416,num,14,GREEN,True,w=300)
        p.text(x+26,462,title,26,bold=True,w=350);p.text(x+26,514,desc,13,MUTE,w=365)
        p.btn(x+26,579,'开始体验  →',target,354)
    p.text(68,718,'38 个页面与状态  /  桌面 + 移动端  /  原生可编辑组件',16,'#DBE5DA')
    p.text(68,766,'基于现有 v0.3.0 项目。后台为本轮补充设计，尚未在产品中实现。',14,'#B6C8BC')
    p.btn(68,843,'任务流程','flow',180,'secondary');p.btn(266,843,'规则与边界','rules',180,'secondary');p.btn(464,843,'移动端预览','mobile-home',180,'secondary')

    p=Page('home','01 · 学习总览',note='继续练习进入训练页；题库、导入、错题和教练设置均可导航。首页数字为样例。',rules='R00 · R05')
    p.shell();p.head('每天 10 分钟  /  让理解多走一步','今天，也来下一步好棋。','从一个小局面开始，把“会走”练成“懂棋”。')
    p.box(270,236,742,304,GREEN,r=18);p.pill(298,262,'今日推荐 · 炮类基础',fill='#447565',color=WHITE,w=170)
    p.text(300,317,'隔一子，才是炮',32,WHITE,True,w=600)
    p.text(300,374,'找到炮架，理解炮的吃子规则。',16,'#CEE0D2',w=600)
    p.btn(300,454,'继续练习  →','train',220,'secondary')
    # Decorative native chess pieces, not external generated imagery.
    p.box(807,327,116,116,'#FAF1DC',r=99,text='炮',size=64,color=RED,bold=True,align='center',kind='ellipse')
    p.card(1034,236,364,304);p.text(1060,262,'我的学习节奏',18,bold=True,w=300)
    p.text(1060,316,'08',52,GREEN,True,w=150,h=80);p.text(1150,348,'/ 20 道已练习',14,MUTE,w=210)
    p.box(1060,411,310,7,SOFT,r=4);p.box(1060,411,124,7,GREEN,r=4)
    p.text(1060,452,'独立完成 5 道 · 提示后完成 3 道',13,MUTE,w=315)
    p.text(270,577,'把练习变成习惯',21,bold=True)
    for x,title,desc,target,mark in [(270,'练习题库','20 道短局面，按主题练习','library','车'),(654,'导入自己的残局','图片或 FEN，校正后再分析','import','局'),(1038,'回到我的错题','3 道待重练，巩固薄弱规则','mistakes','练')]:
        p.card(x,627,360,208);p.box(x+22,649,46,46,SOFT,r=12,text=mark,size=23,color=GREEN,align='center');p.text(x+22,719,title,19,bold=True,w=310);p.text(x+22,760,desc,13,MUTE,w=318);p.link(x,627,360,208,target,title)
    p.text(270,875,'教练会陪你思考；走法与目标始终由规则工具核验。',13,MUTE)

    p=Page('library','02 · 练习题库',note='主题筛选为原型交互，点击题卡进入炮架示例。20 题来自现有项目，示例只展示部分。',rules='R01 · R05')
    p.shell('练习题库');p.head('练习题库  /  20 道自编教学局面','从懂一个规则开始','8 道基础题 + 12 道残局；按自己的节奏选择。')
    for x,text in [(270,'全部题目'),(406,'基础训练  8'),(564,'残局挑战  12')]:p.btn(x,232,text,'library',140 if x!=270 else 120,'primary' if x==270 else 'secondary')
    p.field(1110,232,288,'搜索题目或规则','search')
    p.text(270,302,'主题',13,MUTE,w=70)
    for x,t in [(328,'全部'),(416,'车'),(504,'马'),(592,'炮'),(680,'兵'),(768,'应将')]:p.pill(x,299,t,SOFT if t=='全部' else WHITE,w=72);p.link(x,299,72,28,'library','筛选 '+t)
    cards=[('车','沿线看远处','车的直线运动','已独立完成'),('炮','隔一子，才是炮','炮架与吃子','继续练习'),('马','马腿在什么位置','日字与蹩马腿','待重练'),('相','看清象眼','田字与象眼','未练习'),('兵','过河以后，多一个方向','过河兵的横走','未练习'),('将','双车接力：两步收网','两步连续将杀','未练习')]
    for i,(mark,title,desc,status) in enumerate(cards):
        x=270+(i%3)*384;y=360+(i//3)*263;p.card(x,y,360,241)
        p.box(x+22,y+22,54,54,CREAM,r=99,text=mark,size=29,color=RED,align='center',kind='ellipse');p.pill(x+191,y+30,status,w=145)
        p.text(x+22,y+102,title,18,bold=True,w=322);p.text(x+22,y+139,desc,13,MUTE,w=318)
        p.btn(x+22,y+179,'开始练习  →','train',316,'secondary')

    training('train','03 · 独立训练')
    training('selected','04 · 选择棋子','selected')
    training('illegal','05 · 非法走法反馈','illegal')
    training('hint1','06 · 一级提示','hint1')
    training('hint2','07 · 二级提示','hint2')
    training('hint3','08 · 三级提示','hint3')
    training('success','09 · 独立完成','success')
    training('assisted','10 · 提示后完成','assisted')

    p=Page('agent-wait','11 · Agent 分析中',note='填写想法后点击复盘才触发模型。这里通过右侧状态入口演示成功、提醒和失败，不发送真实 API 请求。',rules='R06 · R07 · R08')
    p.shell('练习题库');p.head('AI 复盘  /  当前局面','教练正在整理这一步','规则与参考线路已保存，等待时仍可返回棋盘。')
    p.card(270,235,666,666);board(p,350,270,500,done=True)
    p.card(960,235,438,666);p.text(988,262,'告诉教练，你这步想做什么',18,bold=True,w=390)
    p.field(988,311,382,'我想借红车做炮架，吃掉黑车','plan')
    p.text(988,388,'●  正在生成个性化讲解…',18,GREEN,True,w=390)
    for yy,num,txt,status in [(450,'01','重建当前棋盘与实际着法','已完成'),(510,'02','检索“炮架”规则与 E1–E4 证据','已完成'),(570,'03','整理 9–12 岁 · 初学者讲解','进行中')]:
        p.pill(988,yy,num,w=42);p.text(1045,yy+3,txt,13,w=318);p.text(1045,yy+28,status,11,MUTE,w=250)
    p.text(988,662,'单次最多等待 120 秒；失败不会自动重试。',12,MUTE,w=390)
    p.btn(988,709,'返回棋盘','success',382,'secondary')
    p.text(988,784,'原型状态演示',11,MUTE,w=300)
    for x,txt,target in [(988,'成功','report'),(1120,'有提醒','warning'),(1252,'失败','failure')]:p.btn(x,820,txt,target,118,'secondary')

    p=Page('report','12 · 个性化教练复盘',note='用户自述、当前棋盘、规则证据与学习档案共同进入领域 Agent。点击证据查看本地解法，进入自由摆谱可继续探索。示例回复为人工设计文案。',rules='R06 · R07 · R09')
    p.shell('练习题库');p.head('AI 复盘  /  隔一子，才是炮','这一步，懂得更清楚一点。','讲解样例 · 9–12 岁 / 初学者 / 慢节奏',('返回棋盘','success'))
    p.card(270,235,616,666);board(p,328,269,500,done=True)
    p.pill(294,845,'规则已核验');p.text(445,848,'b2 → b7 · 红炮吃黑车',14,w=400)
    coach_card(p,910,235,488,sub='个性化复盘 · AI 生成样例')
    p.box(992,340,406,74,SOFT,r=14,text='我想借红车做炮架，吃掉黑车。',size=14)
    p.box(910,434,488,247,WHITE,LINE,14)
    p.text(934,451,'你找对了关键：中间的那枚车。',18,GREEN,True,w=435)
    for yy,txt in [(497,'红炮从 b2 到 b7，中间只有 b4 的红车。'),(530,'它就是“炮架”——让炮隔一子吃子的支点。'),(563,'这步能吃黑车，规则已核验；不代表整局必胜。')]:p.text(934,yy,txt,14,w=438)
    p.pill(934,615,'E1 路径');p.pill(1047,615,'E2 唯一炮架');p.pill(1198,615,'E3 合法落点')
    p.link(934,610,435,40,'replay','查看工具证据')
    p.box(910,701,488,92,'#F3F4EA',r=14)
    p.text(934,714,'再想一步',14,GREEN,True,w=435);p.text(934,746,'如果中间有两枚棋子，炮还能吃过去吗？',14,w=435)
    p.field(910,813,358,'说说你的想法…','reply');p.btn(1282,814,'发送','followup',116)
    p.text(911,879,'↗ 在棋盘上验证我的想法',13,GREEN,w=460);p.link(910,869,488,35,'study','进入自由摆谱')

    p=Page('followup','13 · 教练追问',note='发送想法后示例追问。模型不能改变棋盘和判定；点击摆谱用规则验证。',rules='R06 · R09')
    p.shell('专属教练');p.head('对话与验证','把想法带到棋盘上','领域 Agent：回应你的计划 → 引用依据 → 留下可独立完成的问题。')
    p.card(270,236,1128,665);coach_card(p,302,264,1064,sub='当前任务：炮架与吃子')
    p.box(749,374,582,69,SOFT,r=14,text='有两枚棋子就不能吃，因为只能隔一个炮架。',size=16)
    p.box(336,476,869,165,BG,r=14)
    p.text(360,497,'是的，你抓住了“恰好一个”。',21,GREEN,True,w=800)
    p.text(360,550,'现在试着移动红车，观察炮架数量变化后，哪些落点仍然合法。',16,w=800)
    p.text(360,590,'文字回答是学习反馈；实际走法仍由本地规则工具验证。',13,MUTE,w=800)
    p.btn(336,691,'从当前局面开始摆谱','study',360);p.btn(720,691,'返回逐步复盘','report',300,'secondary')

    for key,title,alert,body in [('warning','14 · 讲解一致性提醒','调用成功，有内容需要留意','文字提到的胜负结论与当前工具证据不一致。'),('failure','15 · 模型调用失败','这次讲解没有生成','连接超时。棋盘与规则记录已保留，可手动重试。')]:
        p=Page(key,title,note='提醒保留模型原文并突出标记；结构或网络失败不填入本地答案、不自动重试、不改变独立资格。',rules='R07 · R08')
        p.shell('练习题库');p.head('AI 复盘 / 调用状态',alert,body)
        p.card(270,235,666,666);board(p,350,270,500,done=True)
        p.box(960,235,438,199,'#FFF4E5',r=16);p.text(988,263,'! '+alert,20,AMBER,True,w=388)
        p.text(988,314,body[:23],14,AMBER,w=390);p.text(988,347,body[23:],14,AMBER,w=390)
        p.card(960,456,438,270)
        p.text(988,477,'保留的内容',17,bold=True,w=380)
        for yy,t in [(523,'✓ 当前棋盘与实际着法'),(566,'✓ 本地参考解法与规则证据'),(609,'✓ 本次作答与完成方式')]:p.text(988,yy,t,15,w=380)
        p.text(988,664,'原文样例：“这步说明红方已经必胜。”' if key=='warning' else '讲解区暂时为空，等待你手动重试。',12,MUTE,w=388)
        p.btn(960,751,'查看带提醒的讲解' if key=='warning' else '手动重试讲解','report' if key=='warning' else 'agent-wait',438)
        p.btn(960,815,'查看本地解法','replay',438,'secondary')

    p=Page('replay','16 · 本地解法回放',note='回放线路来自本地工具；前后步骤及走前/走后切换可演示。不会修改作答或统计。从当前局面开始摆谱另开探索状态。',rules='R03 · R09')
    p.shell('练习题库');p.head('解法回放  /  本地规则核验','看见每一步的依据','参考线路是可行解示例，不声称是唯一最优解。',('返回复盘','report'))
    p.card(270,235,666,666);board(p,350,270,500,done=True)
    p.btn(300,842,'◀ 走前','selected',180,'secondary');p.btn(502,842,'走后 ▶','replay',180,'secondary');p.btn(704,842,'翻转棋盘','replay',200,'secondary')
    p.card(960,235,438,666);p.text(988,260,'步骤 1 / 1',15,MUTE,w=380)
    p.text(988,303,'炮 b2 → b7',26,bold=True,w=380);p.pill(988,359,'目标已达成')
    for yy,t,desc in [(418,'E1 · 路径核验','沿 b 线移动，起终点同一直线。'),(500,'E2 · 炮架核验','中间恰有 b4 红车一枚棋子。'),(582,'E3 · 安全与目标','合法吃掉目标黑车，帅将安全。')]:p.text(988,yy,t,16,GREEN,True,w=380);p.text(988,yy+34,desc,13,MUTE,w=380)
    p.btn(988,703,'从此处开始自由摆谱','study',382)
    p.text(988,780,'当前：黑方行棋',14,w=380);p.text(988,815,'核验信息随当前回放局面更新。',12,MUTE,w=380)

    p=Page('study','17 · 自由摆谱',note='当前演示移动炮到 c2 后的新局面。摆谱不更改作答统计，走棋不自动调用模型。只有点击分析才进入等待状态。',rules='R06 · R09')
    p.shell('练习题库');p.head('自由摆谱  /  探索你的想法','试一试，棋理会更清楚。','分支独立保存于本次探索，不改变原题成绩。',('退出摆谱','replay'))
    p.card(270,235,666,666);board(p,350,270,500,mode='study')
    p.btn(300,842,'悔棋','selected',180,'secondary');p.btn(502,842,'重摆','study',180,'secondary');p.btn(704,842,'返回主线','replay',200,'secondary')
    coach_card(p,960,235,438,sub='摆谱时不自动调用模型')
    p.card(960,338,438,335);p.text(988,364,'当前探索',18,bold=True,w=380)
    p.pill(988,411,'红方走');p.text(988,460,'1. 炮 b2 → c2',17,w=380)
    p.text(988,511,'这一步想做什么？',14,bold=True,w=380);p.field(988,551,382,'我想看看离开 b 线还能不能吃车','study-plan')
    p.btn(960,699,'AI 分析当前局面','agent-wait',438)
    p.text(962,774,'移动后旧分析不再用于新棋盘。',13,MUTE,w=420);p.text(962,813,'最多 80 步；未保存分支刷新后不恢复。',12,MUTE,w=420)

    p=Page('import','18 · 导入残局',note='本原型通过选择示例图片演示；不上传真实图片。支持图片与 FEN 两种入口，图片必须四角校准后人工核对。',rules='R10 · R06')
    p.shell('导入残局');p.head('我的残局研究室','把遇到的局面，变成练习。','图片导入或粘贴 FEN；先确认棋盘，再进行分析。')
    p.card(270,236,716,657);p.btn(298,264,'图片导入','import',160);p.btn(474,264,'FEN 导入','import-confirm',160,'secondary')
    p.box(298,336,660,341,BG,LINE,16);p.text(540,397,'⊞',55,GREEN,w=130)
    p.text(442,492,'拖入棋盘图片，或点击选择',21,bold=True,w=450)
    p.text(446,538,'PNG / JPEG / WebP · 最大 10 MB',14,MUTE,w=450)
    p.btn(466,603,'选择示例图片','import-crop',312)
    p.text(298,719,'也可以粘贴棋盘 FEN',14,bold=True,w=600);p.field(298,761,660,'3k5/9/4R4/9/9/9/9/9/9/4K4 w','fen')
    p.btn(750,829,'解析 FEN','import-confirm',208,'secondary')
    coach_card(p,1010,236,388,sub='识别是辅助，确认由你完成')
    p.card(1010,338,388,325)
    for yy,num,t in [(365,'01','选四个最外侧交叉点'),(441,'02','裁剪识别，检查可疑棋位'),(517,'03','人工确认，开始局面分析')]:p.pill(1032,yy,num,w=42);p.text(1090,yy+3,t,14,w=285)
    p.text(1032,598,'不会根据位置猜补缺失的帅将。',12,MUTE,w=345)

    p=Page('import-crop','19 · 四角校准',note='依次标记左上、右上、右下、左下最外侧交叉点。确认方向后才识别；识别冲突在下一页提示，不直接判胜。',rules='R10')
    p.shell('导入残局');p.head('图片导入  /  1 校准 → 2 核对 → 3 分析','对齐棋盘的四个角','选择的是最外侧交叉点；不包含棋盘外框。')
    p.card(270,236,716,665);board(p,364,267,500,mode='import')
    for i,(xx,yy) in enumerate([(414,306),(814,306),(814,756),(414,756)]):p.box(xx-14,yy-14,28,28,GREEN,r=99,text=str(i+1),size=13,color=WHITE,align='center',kind='ellipse')
    p.card(1010,236,388,665);p.text(1034,264,'棋盘方向',18,bold=True,w=340)
    p.btn(1034,313,'红方在下 ✓','import-crop',340,'secondary')
    p.text(1034,396,'角点微调',17,bold=True,w=340)
    for i,t in enumerate(['左上  10% , 8%','右上  90% , 8%','右下  90% , 92%','左下  10% , 92%']):p.field(1034,440+i*59,340,t,'corner-'+str(i))
    p.text(1034,707,'识别最多调用 3 次模型；需有效 API 设置。',12,MUTE,w=342)
    p.btn(1034,756,'裁剪识别＋字形复核','import-confirm',340)
    p.btn(1034,820,'重新选图','import',340,'secondary')

    p=Page('import-confirm','20 · 人工核对棋位',note='可疑棋位不会擅自补子；用户核对并勾选后才能分析。FEN 解析复用核对入口。',rules='R10 · R01')
    p.shell('导入残局');p.head('图片导入  /  1 校准 → 2 核对 → 3 分析','先确认，再相信。','请对照原图检查红黑、棋位与行棋方。')
    p.card(270,236,716,665);board(p,364,267,500,mode='import')
    p.card(1010,236,388,665);p.pill(1034,263,'1 处需要留意',fill='#FFF0D9',color=AMBER,w=160)
    p.text(1034,317,'e7：红车 / 字形置信度偏低',16,bold=True,w=342)
    p.text(1034,360,'对照原图后选择棋子修正。',13,MUTE,w=342)
    for i,t in enumerate(['红车 ✓','红炮','黑车','清空']):p.btn(1034+(i%2)*177,413+(i//2)*58,t,'import-confirm',163,'secondary')
    p.text(1034,563,'行棋方',14,bold=True,w=340);p.btn(1034,603,'红方先行 ✓','import-confirm',340,'secondary')
    p.box(1034,684,340,58,SOFT,r=10,text='☑ 我已核对棋位与行棋方',size=14,color=GREEN)
    p.link(1034,684,340,58,'import-confirm','切换人工确认')
    p.btn(1034,774,'确认棋盘，分析局面','import-result',340)
    p.btn(1034,834,'返回校准','import-crop',340,'secondary')

    p=Page('import-result','21 · 残局分析结果',note='本地短杀搜索与引擎参考先展示；AI 逐步讲解由按钮触发。短杀未发现不等于必输或和棋。',rules='R02 · R06 · R10')
    p.shell('导入残局');p.head('残局研究  /  帅车合力封宫','这盘棋，从封住退路开始。','已人工确认 · 红方先行 · 本地分析完成',('重新导入','import'))
    p.card(270,236,716,665);board(p,364,267,500,mode='import')
    p.card(1010,236,388,665);p.pill(1034,264,'规则工具 · 已验证',w=174)
    p.text(1034,321,'找到一步连续将杀',22,GREEN,True,w=342)
    p.text(1034,374,'参考首着：车 e7 → d7',16,w=342)
    p.text(1034,428,'车沿 d 线将军，红帅限制将的退路。',13,MUTE,w=342)
    p.text(1034,475,'短杀范围：红方最多 1 次将军',13,MUTE,w=342)
    p.box(1034,530,340,110,BG,r=12)
    p.text(1050,545,'引擎参考 · 尚未请求',15,bold=True,w=310);p.text(1050,582,'与规则目标分开呈现，不换算胜率。',12,MUTE,w=310)
    p.btn(1034,677,'查看本地解法','replay',340,'secondary');p.btn(1034,741,'DS 逐步讲解','agent-wait',340)
    p.btn(1034,805,'导出分析记录','import-result',340,'secondary')

    p=Page('mistakes','22 · 我的错题',note='错误自动进入错题本。重练保留来源，独立完成和辅助完成分别记账；不把浏览器统计当棋力测评。',rules='R04 · R05')
    p.shell('我的错题');p.head('巩固练习  /  从错误中多懂一点','再看一次，就更进一步。','这里记录需要重练的规则点；错误不是能力标签。')
    for x,n,t in [(270,'3','待重练'),(654,'5','已独立巩固'),(1038,'炮架','当前重点')]:p.card(x,235,360,126);p.text(x+24,253,n,32,GREEN,True,w=310);p.text(x+24,314,t,13,MUTE,w=310)
    p.card(270,390,1128,454);p.text(296,415,'题目 / 薄弱规则',14,MUTE,w=600);p.text(885,415,'最近结果',14,MUTE,w=270)
    for i,(title,desc,status) in enumerate([('隔一子，才是炮','炮架与吃子','合法未达目标'),('马腿在什么位置','方向与马腿','非法尝试'),('先解决自己的将军','应将与帅将安全','提示后完成')]):
        yy=474+i*112;p.box(296,yy-10,1076,1,LINE,r=0);p.text(296,yy+6,title,18,bold=True,w=520);p.text(296,yy+43,desc,13,MUTE,w=520);p.pill(879,yy+14,status,w=155);p.btn(1161,yy+7,'重新练习','train',208,'secondary')
    p.btn(270,873,'导出学习记录','mistakes',220,'secondary');p.text(515,885,'数据仅保存在当前浏览器，可通过备份迁移。',12,MUTE,w=850)

    p=Page('profile','23 · 我的专属教练',note='仅保存枚举学习偏好，不要求姓名学校。更改设置不自动调用模型，下次主动请求使用新设置。',rules='R06 · R11')
    p.shell('专属教练');p.head('学习偏好  /  适合自己的解释','让教练用你听得懂的方式说。','只选择学习偏好，无需姓名、学校或联系方式。')
    p.card(270,235,716,665)
    opts=[('年龄段',['6–8 岁','9–12 岁','13–17 岁','成人'],1),('学习水平',['刚开始学棋','了解基础规则','想练战术'],0),('练习目标',['走子规则','短局面战术','复盘思考'],0),('讲解节奏',['慢一点','标准','简洁'],0)]
    for i,(label,choices,sel) in enumerate(opts):
        yy=267+i*135;p.text(298,yy,label,16,bold=True,w=630)
        for j,t in enumerate(choices):p.box(298+j*164,yy+42,150,46,SOFT if j==sel else WHITE,GREEN if j==sel else LINE,10,t,14,GREEN,align='center',target='profile')
    p.btn(298,831,'保存学习偏好','home',660)
    coach_card(p,1010,235,388,sub='当前：9–12 岁 · 刚开始学棋')
    p.card(1010,338,388,355);p.text(1034,363,'教练会这样解释',18,bold=True,w=342)
    for yy,t in [(416,'先看中间的红车。'),(454,'炮吃子，需要隔着恰好一枚棋子。'),(492,'这枚棋子，就叫“炮架”。')]:p.text(1034,yy,t,14,w=342)
    p.text(1034,575,'短句 + 一个观察点 + 一个自检问题',12,GREEN,w=342);p.text(1034,623,'已有讲解保持原样，下次请求使用新偏好。',11,MUTE,w=342)

    p=Page('settings','24 · API 与隐私设置',note='页面密钥仅存内存；刷新需重输；应用不等于连接测试成功。原型不提交、保存或测试任何真实 Key。',rules='R06 · R11 · R12')
    p.shell('专属教练');p.head('连接设置','让 AI 在需要时加入。','基础练习与本地规则，无需模型也可使用。')
    p.card(270,235,716,665);p.text(298,262,'DeepSeek API',23,bold=True,w=660)
    p.text(298,325,'API Key · 仅当前页面有效',14,bold=True,w=650);p.field(298,363,660,'输入你的 API Key（原型不保存）','api-key','password')
    p.text(298,445,'模型',14,bold=True,w=650);p.btn(298,483,'deepseek-flash ✓','settings',314,'secondary');p.btn(628,483,'deepseek-v4-pro','settings',330,'secondary')
    p.box(298,576,660,112,BG,r=12);p.text(318,591,'当前状态：未测试连接',16,bold=True,w=610);p.text(318,633,'“应用并测试”将发送一次短请求，原型仅模拟反馈。',13,MUTE,w=610)
    p.btn(298,730,'应用并测试连接','settings',316);p.btn(634,730,'仅应用','settings',324,'secondary');p.btn(298,800,'清除本页密钥','settings',660,'secondary')
    p.card(1010,235,388,440);p.text(1034,264,'由你决定何时调用',19,bold=True,w=340)
    for yy,txt in [(322,'主动点击 AI 功能才发起请求。'),(370,'密钥不写入本地存储或文件。'),(418,'刷新页面后需要重新输入。'),(466,'失败不会自动重试付费调用。'),(514,'学习档案只包含偏好枚举。')]:p.text(1034,yy,txt,13,MUTE,w=342)
    p.btn(1034,593,'返回练习','train',340,'secondary')

    # Necessary administration surfaces, explicitly proposed rather than already shipped.
    p=Page('admin','25 · 后台工作台','管理端',note='后台为新增原型范围。统计均为演示样例；角色为内容管理员。用户学习记录仍留本地，不虚构后台用户账号系统。',rules='R13 · R14')
    p.shell('工作台',True);p.head('教学内容与质量  /  CONTENT STUDIO','让每一份讲解，都有可靠依据。','管理题库、规则知识与 Agent 运行质量。')
    for x,n,label,sub in [(270,'20','已发布题目','8 基础 / 12 残局'),(654,'7','规则知识条目','固定来源，可追溯'),(1038,'2','待审查调用','1 提醒 / 1 失败 · 样例')]:
        p.card(x,235,360,160);p.text(x+24,251,n,40,GREEN,True,w=310);p.text(x+24,316,label,16,bold=True,w=310);p.text(x+24,351,sub,12,MUTE,w=310)
    p.card(270,423,716,420);p.text(296,448,'内容工作流',21,bold=True,w=640)
    for i,(t,d,target) in enumerate([('维护训练题库','FEN、目标、提示、教案与可解性核验','puzzles-admin'),('维护领域知识','规则条目、适用范围与固定源码来源','knowledge'),('审查 Agent 结果','工具证据、结构校验与内容一致性提醒','logs')]):
        yy=511+i*101;p.pill(296,yy,str(i+1).zfill(2),w=44);p.text(357,yy,t,17,bold=True,w=540);p.text(357,yy+35,d,13,MUTE,w=540);p.link(290,yy-8,666,80,target,t)
    p.card(1010,423,388,420);p.text(1034,449,'运行约定',19,bold=True,w=340)
    for yy,t in [(512,'规则决定合法性与任务达成。'),(564,'引擎只提供局面参考。'),(616,'Agent 负责因果解释与追问。'),(668,'发布前必须完成规则核验。')]:p.text(1034,yy,t,14,w=340)
    p.btn(1034,751,'查看 Agent 记录','logs',340,'secondary')

    p=Page('puzzles-admin','26 · 题库管理','管理端',note='编辑题目后先核验再发布。演示中的筛选和搜索不会请求生产数据。',rules='R13 · R14')
    p.shell('题库管理',True);p.head('内容管理  /  训练题库','每个局面，都有明确目标。','20 个已发布局面 · 1 个编辑草稿（演示）',('新建题目','puzzle-edit'))
    p.field(270,235,470,'搜索题目名称或 ID','admin-search');p.btn(765,236,'全部状态 ▾','puzzles-admin',200,'secondary');p.btn(985,236,'全部主题 ▾','puzzles-admin',200,'secondary')
    p.card(270,309,1128,580)
    for xx,t in [(296,'题目'),(760,'类型 / 难度'),(978,'状态'),(1213,'操作')]:p.text(xx,331,t,13,MUTE,w=410)
    rows=[('隔一子，才是炮','cannon-screen','基础 / 1 星','已发布'),('马腿在什么位置','horse-leg','基础 / 2 星','已发布'),('帅车合力封宫','ending-rook-king','残局 / 2 星','已发布'),('双车接力：两步收网','ending-ladder-two','残局 / 3 星','已发布'),('炮架练习·教案调整','cannon-screen-draft','基础 / 1 星','草稿')]
    for i,(t,id,cat,status) in enumerate(rows):
        yy=388+i*94;p.box(296,yy-10,1076,1,LINE,r=0);p.text(296,yy,t,16,bold=True,w=430);p.text(296,yy+32,id,12,MUTE,w=430);p.text(760,yy+14,cat,13,w=210);p.pill(978,yy+6,status,w=105);p.btn(1190,yy+1,'编辑','puzzle-edit',180,'secondary')

    p=Page('puzzle-edit','27 · 题目编辑与核验','管理端',note='FEN 必须可解析；目标与训练规则一致；将杀题穷举全部合法应对。核验通过后打开发布预览，再发布。',rules='R01 · R02 · R13')
    p.shell('题库管理',True);p.head('题库 / 编辑草稿','隔一子，才是炮','未发布 · 最后编辑：内容管理员（演示）')
    p.card(270,235,716,665)
    for yy,label,value in [(260,'题目名称','隔一子，才是炮'),(363,'初始 FEN','4k4/9/1r7/9/9/1R2P4/9/1C7/9/4K4 w'),(466,'明确的任务目标','用红炮一步吃掉 b7 的黑车。'),(569,'三级提示（由观察到示例）','1 找炮架；2 观察 b4；3 b2 → b7')]:p.text(298,yy,label,14,bold=True,w=660);p.field(298,yy+34,660,value,label)
    p.text(298,683,'关联知识',14,bold=True,w=660);p.pill(298,720,'cannon · 炮架',w=170)
    p.btn(298,831,'保存草稿','puzzles-admin',316,'secondary');p.btn(634,831,'运行规则核验','publish',324)
    p.card(1010,235,388,665);p.text(1034,263,'发布前检查',20,bold=True,w=340)
    for i,t in enumerate(['FEN 可解析，帅将完整','行棋方与目标匹配','参考着法合法且达标','全部合法正确解可接受','三级提示与证据相符']):p.text(1034,331+i*62,'○  '+t,14,w=340)
    p.text(1034,690,'AI 文案不能替代可解性核验。',13,AMBER,w=340)

    p=Page('publish','28 · 核验与发布预览','管理端',note='核验完成后才允许点击发布；发布保存审计记录与版本。当前仅设计模拟，无生产写入。',rules='R13 · R14')
    p.shell('题库管理',True);p.head('发布检查','核验通过，准备发布。','目标、正确解与提示一致后，才进入学习端。')
    p.card(270,235,1128,663)
    for i,t in enumerate(['FEN 结构有效','参考 b2 → b7 合法且吃到目标','炮架为 b4 红车，数量恰为 1','完整枚举合法达标走法','提示由观察递进到示例']):p.text(310,275+i*66,'✓  '+t,17,GREEN,w=1000)
    p.box(310,635,1048,100,BG,r=12);p.text(334,649,'发布版本 v1.1 · 炮架教案调整',17,bold=True,w=1000);p.text(334,691,'影响：后续新练习使用新版本；历史记录保留原版本引用。',13,MUTE,w=1000)
    p.btn(310,790,'确认发布','published',500);p.btn(834,790,'返回修改','puzzle-edit',524,'secondary')

    p=Page('published','29 · 发布完成','管理端',note='发布完成页为模拟结果，可返回题库或打开用户端查看。',rules='R13 · R14')
    p.shell('题库管理',True);p.head('发布完成','新教案已经准备好。','演示发布结果 · 无真实后台写入')
    p.card(270,235,1128,660);p.box(757,315,100,100,SOFT,r=99,text='✓',size=48,color=GREEN,align='center',kind='ellipse');p.text(537,463,'隔一子，才是炮 · v1.1',32,bold=True,w=800)
    p.text(537,535,'规则核验通过，发布事件已记入审计记录（演示）。',15,MUTE,w=800);p.btn(489,659,'返回题库','puzzles-admin',310,'secondary');p.btn(823,659,'查看用户端效果','train',310)

    p=Page('knowledge','30 · 领域知识管理','管理端',note='7 条规则来自现有 knowledge.js；保留固定来源与范围。知识修改应关联受影响题目并重新核验。',rules='R02 · R13')
    p.shell('规则知识',True);p.head('领域知识  /  7 条规则','让讲解有据可查','标签检索 + 规则工具 + 自编教案；未使用向量库或模型微调。')
    p.card(270,235,336,665)
    for i,t in enumerate(['车 · 直线与阻挡','炮 · 炮架','马 · 日字与马腿','相 · 田字与象眼','兵 · 过河与方向','应将 · 帅将安全','将军不等于绝杀']):p.box(290,260+i*80,296,58,SOFT if i==1 else WHITE,r=10,text='  '+t,size=15,color=GREEN,target='knowledge')
    p.card(630,235,768,665);p.pill(660,265,'cannon');p.text(660,317,'炮：炮架',27,bold=True,w=700)
    for yy,t in [(388,'不吃子时沿空直线移动；'),(428,'吃子时与目标之间必须恰好有一个棋子作为炮架。')]:p.text(660,yy,t,18,w=700)
    p.text(660,505,'资料来源',14,bold=True,w=700);p.text(660,544,'固定上游规则实现（MIT）与本项目自编教案',14,MUTE,w=700)
    p.text(660,582,'WildWriter / ChineseChess-with-deepseek · 96ec030…',12,MUTE,w=700)
    p.text(660,650,'适用范围',14,bold=True,w=700);p.text(660,689,'基础走子与短局面，不覆盖长将长捉等比赛裁定。',14,MUTE,w=700)
    p.btn(660,800,'查看关联题目','puzzles-admin',330,'secondary');p.btn(1010,800,'编辑关联教案','puzzle-edit',358)

    p=Page('logs','31 · Agent 运行审查','管理端',note='必要后台补充设计：示例元数据和脱敏证据，不采集浏览器私有学习档案，不显示或记录密钥。',rules='R07 · R08 · R11 · R14')
    p.shell('Agent 运行',True);p.head('质量工作台  /  Agent 运行','看清每次调用的依据与状态','仅展示脱敏诊断信息；以下记录均为原型样例。')
    for x,n,t in [(270,'12','示例调用'),(654,'1','内容一致性提醒'),(1038,'1','结构 / 网络失败')]:p.card(x,235,360,126);p.text(x+24,252,n,34,GREEN,True,w=310);p.text(x+24,313,t,13,MUTE,w=310)
    p.card(270,390,1128,480)
    for x,t in [(296,'请求 / 功能'),(732,'模型'),(1005,'状态'),(1216,'操作')]:p.text(x,415,t,13,MUTE,w=400)
    for i,(id,sub,status) in enumerate([('demo-021','训练复盘 / cannon-screen','成功'),('demo-020','摆谱分析 / 局面变更','已丢弃旧结果'),('demo-019','训练复盘 / cannon-screen','成功（有提醒）'),('demo-018','图片识别 / 超时','失败')]):
        yy=466+i*94;p.box(296,yy-7,1076,1,LINE,r=0);p.text(296,yy,id,16,bold=True,w=400);p.text(296,yy+31,sub,12,MUTE,w=400);p.text(732,yy+15,'deepseek-flash',14,w=250);p.pill(1005,yy+10,status,w=160);p.btn(1204,yy+4,'审查','log-detail',166,'secondary')

    p=Page('log-detail','32 · Agent 证据详情','管理端',note='通过 requestId + positionVersion 绑定证据和局面。内容一致性提醒保留原文；棋盘线路只采纳本地核验结果。',rules='R07 · R08 · R09 · R14')
    p.shell('Agent 运行',True);p.head('Agent 记录 / demo-019','调用成功，但结论需要留意。','讲解可读 · 一致性提醒 1 条 · 原型诊断样例',('返回记录','logs'))
    p.card(270,235,716,665);p.text(298,263,'可追溯的处理链路',21,bold=True,w=660)
    for i,(title,desc) in enumerate([('01  结构化棋盘','positionVersion=12 · 红方固定坐标 · b2 → b7'),('02  标签检索知识','cannon → 炮架规则与自编教学案例'),('03  工具核验','E1 路径 / E2 唯一炮架 / E3 帅将安全 / E4 目标'),('04  个性化提示编排','年龄段、水平与节奏为枚举；自述仅作数据'),('05  模型与输出检查','结构通过；“全局必胜”缺少证据 → 提醒')]):
        yy=326+i*105;p.pill(298,yy,'✓',w=35);p.text(353,yy,title,16,bold=True,w=600);p.text(353,yy+35,desc,12,MUTE,w=600)
    p.card(1010,235,388,665);p.text(1034,264,'提醒明细',20,bold=True,w=340)
    p.box(1034,319,340,180,'#FFF4E5',r=12);p.text(1052,337,'胜负措辞超出工具证据',16,AMBER,True,w=310)
    p.text(1052,387,'原文：“这步说明红方已经必胜。”',12,AMBER,w=310);p.text(1052,438,'工具仅证明本题吃子目标已达成。',12,AMBER,w=310)
    p.text(1034,544,'处理原则',16,bold=True,w=340)
    for yy,t in [(588,'保留原文并展示黄色提醒。'),(631,'不采纳正文中新提出的棋盘线路。'),(674,'不自动发起付费补写。')]:p.text(1034,yy,t,13,MUTE,w=340)
    p.btn(1034,789,'查看用户侧提醒','warning',340,'secondary')

    # Mobile companions use the same semantic flow, with an intentionally compact layout.
    for key,title in [('mobile-home','33 · 移动端总览'),('mobile-train','34 · 移动端训练'),('mobile-coach','35 · 移动端教练')]:
        p=Page(key,title,'移动端',w=390,h=844,note='390×844 移动端设计。下方导航可切换训练与教练。训练先棋盘后反馈，保持触控尺寸。',rules='R15')
        p.text(22,10,'9:41',12,bold=True,w=120);p.text(304,10,'● ▰',12,w=70)
        p.box(20,49,34,34,GREEN,r=10,text='棋',size=20,color=WHITE,align='center');p.text(65,51,'棋理学伴',20,bold=True,w=240)
        if key=='mobile-home':
            p.text(22,116,'今天，也来下一步好棋。',24,bold=True,w=350);p.text(22,159,'从一个小局面，慢慢懂棋。',13,MUTE,w=350)
            p.box(20,210,350,250,GREEN,r=18);p.pill(40,232,'今日推荐',fill='#487665',color=WHITE,w=90)
            p.text(40,286,'隔一子，才是炮',26,WHITE,True,w=310);p.text(40,337,'找到炮架，练懂炮的吃子规则。',13,'#D9E6DB',w=310)
            p.btn(40,389,'开始练习 →','mobile-train',310,'secondary')
            p.card(20,482,350,112);p.text(40,498,'08 / 20',30,GREEN,True,w=310);p.text(40,551,'已练习 · 独立完成 5 道',12,MUTE,w=310)
            p.card(20,617,350,100);p.text(40,632,'我的错题  →',18,bold=True,w=310);p.text(40,673,'3 道待重练，继续巩固炮架与马腿。',12,MUTE,w=310);p.link(20,617,350,100,'mistakes','打开错题')
        elif key=='mobile-train':
            p.text(22,105,'隔一子，才是炮',24,bold=True,w=350);p.text(22,148,'目标：用红炮一步吃掉 b7 黑车',13,MUTE,w=350)
            board(p,20,195,350,selected=True)
            p.box(20,599,350,65,SOFT,r=12,text='已选择 b2 红炮，试着点击 b7。',size=13,color=GREEN)
            p.btn(20,685,'我走好了，和教练复盘','mobile-coach',350)
            p.link(64,244,70,110,'mobile-coach','炮吃黑车演示')
        else:
            p.text(22,107,'和教练，想明白。',24,bold=True,w=350);p.pill(22,154,'9–12 岁 · 初学者',w=167)
            p.box(73,218,297,82,SOFT,r=14,text='我想借红车做炮架，吃掉黑车。',size=13)
            p.card(20,329,350,229);p.text(40,346,'你找对了中间的红车。',19,GREEN,True,w=310)
            for yy,t in [(397,'从 b2 到 b7，中间只有 b4 一枚棋子。'),(431,'它就是“炮架”，让炮隔一子吃过去。'),(465,'规则已核验，这一步完成吃子目标。')]:p.text(40,yy,t,12,w=310)
            p.pill(40,510,'E2 唯一炮架',w=144)
            p.box(20,582,350,93,'#F0F1E6',r=14);p.text(40,593,'再想一步',14,GREEN,True,w=310);p.text(40,631,'如果中间有两枚棋子，还能吃吗？',13,w=310)
            p.btn(20,698,'回棋盘验证','mobile-train',350,'secondary')
        p.box(0,774,390,70,WHITE,LINE,0)
        for x,t,target in [(0,'总览','mobile-home'),(130,'练习','mobile-train'),(260,'教练','mobile-coach')]:p.box(x,788,130,42,'none',r=0,text=t,size=13,color=GREEN,align='center',target=target)

    p=Page('flow','36 · 主要任务与 Agent 流程','设计说明',note='点击流程卡进入对应界面。教练 Agent 通过软件核验工具与 UI 反馈结合，不直接下棋裁决。',rules='R00 · R06 · R13')
    p.text(64,49,'QILI / 任务流程',14,GREEN,True);p.text(64,96,'从一次独立尝试，到理解背后的棋理。',38,bold=True)
    paths=[('学习闭环',[('选择短局面','library'),('自主走棋','train'),('规则即时反馈','illegal'),('完成 / 错题归档','success')]),('领域 Agent',[('表达本步计划','agent-wait'),('棋盘 + 知识 + 证据','log-detail'),('个性化讲解与追问','report'),('回放 / 摆谱验证','study')]),('导入残局',[('图片 / FEN','import'),('四角校准与识别','import-crop'),('人工核对棋位','import-confirm'),('本地分析 / AI 讲解','import-result')]),('后台管理',[('维护题目与教案','puzzle-edit'),('规则可解性核验','publish'),('发布版本','published'),('审查 Agent 状态','logs')])]
    for i,(name,steps) in enumerate(paths):
        yy=227+i*155;p.text(64,yy,name,19,GREEN,True,w=220)
        for j,(t,target) in enumerate(steps):
            xx=260+j*283;p.box(xx,yy-12,250,90,WHITE,LINE,14,text=t,size=16,color=INK,align='center',target=target)
            if j<3:p.text(xx+256,yy+10,'→',21,MUTE,w=30)
    p.text(64,864,'数据原则：规则负责判定，Agent 负责教学；每份分析绑定请求时的局面版本。',15,MUTE)
    p.btn(1168,857,'返回导览','guide',208,'secondary')

    p=Page('rules','37 · 规则与异常设计','设计说明',note='完整规则与页面映射见随附《交互与规则说明.md》。',rules='R00–R15')
    p.text(64,48,'QILI / 规则与边界',14,GREEN,True);p.text(64,99,'让界面反馈，与真实能力一致。',38,bold=True)
    rows=[('训练判定','非法 / 合法未达目标 / 完成目标分开；将杀 ≠ 困毙。'),('学习统计','查看提示或解法后计辅助完成；AI 调用失败不改变独立资格。'),('模型状态','主动调用；等待、成功、有提醒、失败明确呈现；不自动重试。'),('证据与时序','本地核验线路决定棋盘；旧局面的模型结果不覆盖新局面。'),('图片导入','四角校准、明确方向、人工核对；不猜补帅将、不直接判胜。'),('隐私与范围','Key 仅页面内存；档案只存偏好；后台为补充原型设计。')]
    for i,(t,d) in enumerate(rows):
        yy=218+i*102;p.card(64,yy,1312,84);p.text(88,yy+22,t,18,GREEN,True,w=210);p.text(330,yy+24,d,15,w=1020)
    p.btn(64,873,'返回原型导览','guide',240,'secondary');p.btn(328,873,'查看 Agent 审查','log-detail',240)
    # Separate states preserve the model's limitations while making guarded transitions explicit.
    def clone(key,newkey,title):
        q=copy.deepcopy(next(z for z in PAGES if z.key==key));q.key=newkey;q.title=title;PAGES.append(q);return q
    def change(q,old,new):
        for n in q.nodes:
            if old in n['text']:n['text']=n['text'].replace(old,new)
        for l in q.links:
            if old in l['label']:l['label']=l['label'].replace(old,new)
    ready=clone('import-confirm','import-ready','20b · 已确认棋位')
    ready.note='用户已勾选人工核对，现在允许进入分析；取消勾选返回未确认状态。'
    for l in ready.links:
        if l['label']=='切换人工确认':l['target']='import-confirm'
    initial=next(z for z in PAGES if z.key=='import-confirm')
    change(initial,'☑ 我已核对','☐ 我已核对')
    change(initial,'确认棋盘，分析局面','请先完成人工确认')
    for n in initial.nodes:
        if n['text']=='请先完成人工确认':n['fill']='#DCE3DA';n['color']=MUTE
    for l in initial.links:
        if l['label']=='切换人工确认':l['target']='import-ready'
        elif l['target']=='import-result':l['target']='import-confirm'
    def swapboard(q,done=False,mode='preview'):
        q.nodes=[n for n in q.nodes if not (350<=n['x']<=850 and 270<=n['y']<=818)]
        q.links=[l for l in q.links if not l['label'].startswith('棋位 ')]
        # Insert board before side-panel components; no overlap outside the board rectangle.
        board(q,350,270,500,done=done,mode=mode)
    replay=next(z for z in PAGES if z.key=='replay')
    for l in replay.links:
        if l['label']=='◀ 走前':l['target']='replay-before'
        if l['label']=='翻转棋盘':l['label']='返回复盘';l['target']='report'
    change(replay,'翻转棋盘','返回复盘')
    before=clone('replay','replay-before','16b · 回放走前')
    swapboard(before)
    change(before,'当前：黑方行棋','当前：红方行棋 · 走前')
    change(before,'从此处开始自由摆谱','切到走后开始摆谱')
    for l in before.links:
        if l['target']=='study':l['target']='replay'
    study=next(z for z in PAGES if z.key=='study')
    swapboard(study,True)
    change(study,'红方走','黑方走')
    change(study,'1. 炮 b2 → c2','分支 0 步 · 点击 e9 黑将')
    change(study,'我想看看离开 b 线还能不能吃车','我想移动黑将，看看炮的将线')
    for f in study.fields:
        if f['name']=='study-plan':f['placeholder']='我想移动黑将，看看炮的将线'
    for l in study.links:
        if l['label']=='悔棋':l['target']='study'
        if l['target']=='agent-wait':l['target']='study-report'
    study.link(577,286,40,40,'study-selected','选择黑将 e9')
    study.note='从本地解法走后局面进入独立摆谱。点击 e9 黑将，再点 d9 完成一步合法探索；不改变原题与成绩。'
    selected=clone('study','study-selected','17b · 摆谱选择黑将')
    selected.box(574,283,46,46,'none',GREEN,99,kind='ellipse')
    selected.box(541,300,12,12,GREEN,r=99,kind='ellipse')
    selected.link(527,286,40,40,'study-moved','黑将 e9 → d9')
    moved=clone('study','study-moved','17c · 摆谱分支走后')
    swapboard(moved,True,'branch')
    change(moved,'黑方走','红方走');change(moved,'分支 0 步 · 点击 e9 黑将','1. 黑将 e9 → d9')
    moved.links=[l for l in moved.links if l['label']!='选择黑将 e9']
    sr=clone('report','study-report','17d · 摆谱 Agent 反馈')
    sr.nodes=[n for n in sr.nodes if not (328<=n['x']<=828 and 269<=n['y']<=817)]
    board(sr,328,269,500,done=True,mode='branch')
    change(sr,'AI 复盘  /  隔一子，才是炮','摆谱分析  /  当前分支')
    change(sr,'我想借红车做炮架，吃掉黑车。','我想移动黑将，看看炮的将线。')
    change(sr,'你找对了关键：中间的那枚车。','黑将换位了，先重新检查将线。')
    change(sr,'红炮从 b2 到 b7，中间只有 b4 的红车。','黑将由 e9 到 d9，当前轮到红方。')
    change(sr,'它就是“炮架”——让炮隔一子吃子的支点。','红炮在 b7；先找可将军的线，再数炮架。')
    change(sr,'这步能吃黑车，规则已核验；不代表整局必胜。','这一步通过合法性检查，尚未证明局面胜负。')
    change(sr,'如果中间有两枚棋子，炮还能吃过去吗？','想用炮将军，炮与黑将之间需要几枚棋子？')
    change(sr,'b2 → b7 · 红炮吃黑车','e9 → d9 · 黑方走后')
    sr.note='摆谱分析样例只使用当前分支局面；主动点击后展示，不自动调用真实模型。'
    for l in sr.links:
        if l['label']=='返回棋盘':l['target']='study-moved'
        if l['target']=='study':l['target']='study-moved'
    count=str(len(PAGES))
    guide=next(z for z in PAGES if z.key=='guide')
    change(guide,'38 个页面与状态',count+' 个页面与状态')
    return PAGES

def svg(p):
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{p.w}" height="{p.h}" viewBox="0 0 {p.w} {p.h}" role="img" aria-label="{html.escape(p.title)}">', '<style>text{font-family:"Microsoft YaHei","PingFang SC",sans-serif}</style>']
    for n in p.nodes:
        x,y,w,h=n['x'],n['y'],n['w'],n['h'];f=n['fill'];s=n['stroke']
        if n['kind']=='line':parts.append(f'<line x1="{x}" y1="{y}" x2="{x+w}" y2="{y+h}" stroke="{f}" stroke-width="1"/>');continue
        if n['kind']=='ellipse':parts.append(f'<ellipse cx="{x+w/2}" cy="{y+h/2}" rx="{w/2}" ry="{h/2}" fill="{f}" stroke="{s}"/>')
        elif f!='none' or s!='none':parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{n["r"]}" fill="{f}" stroke="{s}"/>')
        if n['text']:
            anchor='middle' if n['align']=='center' else 'start';tx=x+w/2 if anchor=='middle' else x;ty=y+h/2+n['size']*.34
            parts.append(f'<text x="{tx}" y="{ty}" text-anchor="{anchor}" font-size="{n["size"]}" font-weight="{700 if n["bold"] else 400}" fill="{n["color"]}">{html.escape(n["text"])}</text>')
    parts.append('</svg>');return ''.join(parts)

if __name__=='__main__':
    build();(ROOT/'screens').mkdir(parents=True,exist_ok=True)
    for p in PAGES:(ROOT/'screens'/f'{p.key}.svg').write_text(svg(p),encoding='utf-8')
    data=[dict(key=p.key,title=p.title,section=p.section,w=p.w,h=p.h,note=p.note,rules=p.rules,nodes=p.nodes,links=p.links,fields=p.fields) for p in PAGES]
    (ROOT/'design.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'design-data.js').write_text('window.QILI_PAGES='+json.dumps(data,ensure_ascii=False)+';',encoding='utf-8')
    print(f'Built {len(PAGES)} screens, {sum(len(p.nodes) for p in PAGES)} editable shapes, {sum(len(p.links) for p in PAGES)} hotspots.')
