"""Author real editable Pencil components via the running tool, not a renamed export."""
import json,sys,html,time
from pencil_bridge import call,eval_app,ROOT

def color(c):return '#00000000' if c=='none' else c+'FF' if len(c)==7 else c
def element(n,i):
    prop={'fillColor':color(n['fill']),'strokeColor':color(n['stroke']),'strokeStyle':'1|' if n['stroke']!='none' else '0|','textContent':html.escape(n['text']),'textFont':f'Microsoft YaHei|{"bold" if n["bold"] else "normal"}|normal|{n["size"]}px|none|1.2','textColor':color(n['color']),'textAlign':'1,1' if n['align']=='center' else '0,1','textPadding':'0,0','radius':f'{n["r"]},0'}
    typ='Evolus.Common:ms-oval' if n['kind']=='ellipse' else 'Evolus.Common:RoundedRect'
    if n['kind']=='line':
        # Exact diagonals use Pencil's native two-point line.
        return dict(id=f'n{i}',type='Evolus.Common:2pointline',x=n['x'],y=n['y'],properties={'a':'0,0','b':f'{n["w"]},{n["h"]}','strokeColor':color(n['fill']),'strokeStyle':'1|'})
    if n['kind']=='ellipse':prop.pop('radius')
    return dict(id=f'n{i}',type=typ,x=n['x'],y=n['y'],box={'w':n['w'],'h':n['h']},properties=prop)

def author(smoke=False,resume=False):
    pages=json.loads((ROOT/'design.json').read_text(encoding='utf-8'))
    if smoke:pages=[pages[1]]
    # A fresh, separate design document is safe and prevents duplicate pages on reruns.
    if not resume:eval_app('() => {Pencil.controller.modified=false;return new Promise(resolve => Pencil.documentHandler.newDocument({skipFontReload:true},()=>resolve(true)))}')
    initial=call('get_active_document')['pages'] if not resume else []
    saved=json.loads((ROOT/'pencil-map.json').read_text(encoding='utf-8')) if resume else {'pages':{},'authored':[]}
    ids=saved['pages'];logs=saved['authored']
    def activate(pid):
        eval_app('''id=>{for(const p of Pencil.controller.doc.pages){if(!p.lastUsed)p.lastUsed=new Date(0);}const p=Pencil.controller.findPageById(id);Pencil.controller.activatePage(p);return true;}''',pid)
    for p in pages:
        if resume and p['key'] in ids and p['key'] not in ['guide','import-confirm','replay','study']:continue
        if p['key'] in ids:
            pid=ids[p['key']];activate(pid)
            eval_app('''() => {const canvas=Pencil.controller.activePage.canvas;while(canvas.drawingLayer.firstChild)canvas.drawingLayer.firstChild.remove();canvas._sayContentModified();return true;}''')
        else:
            eval_app('''()=>{for(const p of Pencil.controller.doc.pages)if(!p.lastUsed)p.lastUsed=new Date(0);return true;}''')
            res=call('create_page',dict(title=p['title'],width=p['w'],height=p['h'],background='#F6F7F3FF'))
            pid=res['page']['id'];ids[p['key']]=pid;activate(pid)
        els=[element(n,i) for i,n in enumerate(p['nodes'])]
        r=call('insert_shapes',{'pageId':pid,'elements':els})
        logs.append(dict(key=p['key'],id=pid,shapeCount=len(els),idMap=r.get('idMap',{})))
        print('Created',p['key'],len(els),'shapes',flush=True)
    for page in initial:call('delete_page',{'pageId':page['id']})
    (ROOT/'pencil-map.json').write_text(json.dumps(dict(pages=ids,authored=logs),ensure_ascii=False,indent=2),encoding='utf-8')
    if smoke:
        print(call('export_page',{'pageId':ids['home'],'format':'png','outputPath':str(ROOT/'qa'/'pencil-smoke.png')}));return
    # Add invisible, editable native hotspots and link metadata after all target IDs exist.
    for p in pages:
        activate(ids[p['key']])
        eval_app('''()=>{const canvas=Pencil.controller.activePage.canvas;[...canvas.drawingLayer.children].filter(n=>n.hasAttributeNS(PencilNamespaces.p,'QiliInteraction')).forEach(n=>n.remove());canvas._sayContentModified();return true;}''')
        hotspots=[]
        for i,l in enumerate(p['links']):
            hotspots.append(dict(id=f'link{i}',type='Evolus.Common:RoundedRect',x=l['x'],y=l['y'],box={'w':l['w'],'h':l['h']},properties={'fillColor':'#00000000','strokeColor':'#00000000','strokeStyle':'0|','radius':'0,0','textContent':''}))
        r=call('insert_shapes',dict(pageId=ids[p['key']],elements=hotspots)) if hotspots else {'idMap':{}}
        meta=[dict(shapeId=r['idMap'][f'link{i}'],target=ids[l['target']],label=l['label']) for i,l in enumerate(p['links'])]
        eval_app('''args => {const p=Pencil.controller.findPageById(args.pageId);Pencil.controller.retrievePageCanvas(p);const canvas=p.canvas; for(const l of args.links){const node=canvas.drawingLayer.querySelector('[id="'+l.shapeId+'"]');if(!node)throw new Error('Missing hotspot '+l.shapeId);node.setAttributeNS(PencilNamespaces.p,'p:RelatedPage',l.target);node.setAttributeNS(PencilNamespaces.p,'p:QiliInteraction',l.label);}p.note=RichText.fromString(args.note);Pencil.controller.sayDocumentChanged();return args.links.length;}''',dict(pageId=ids[p['key']],links=meta,note=p['note']+'\n规则：'+p['rules']))
        print('Linked',p['key'],len(meta),'hotspots',flush=True)
    activate(ids['guide'])
    path=str(ROOT/'qili-prototype.epgz')
    result=eval_app('''async dest => {const c=Pencil.controller; c.documentPath=dest; c.oldPencilDoc=false;for(const p of c.doc.pages)p.thumbCreated=new Date(); await new Promise(r=>c.serializeDocument(r)); const h=Pencil.documentHandler.getHandlerForFilePath(dest);await h.saveDocument(dest);c.sayDocumentSaved(); return {path:dest,pages:c.doc.pages.length};}''',path)
    (ROOT/'qa'/'pencil-authoring.json').write_text(json.dumps(dict(result=result,log=logs),ensure_ascii=False,indent=2),encoding='utf-8')
    print(result,flush=True)

if __name__=='__main__':
    (ROOT/'qa').mkdir(exist_ok=True)
    author('--smoke' in sys.argv,'--resume' in sys.argv)
