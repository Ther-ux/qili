import json, urllib.request, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

def call(name, args=None):
    body = json.dumps({'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':name,'arguments':args or {}}}).encode()
    req = urllib.request.Request('http://127.0.0.1:1919/mcp', data=body, headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream'})
    raw = urllib.request.urlopen(req, timeout=180).read().decode()
    if raw.startswith('event:'):
        raw = next(x[6:] for x in raw.splitlines() if x.startswith('data: '))
    result = json.loads(raw)
    if 'error' in result: raise RuntimeError(result['error'])
    res = result['result']
    if res.get('isError'): raise RuntimeError(res)
    txt = [x['text'] for x in res.get('content',[]) if x.get('type')=='text']
    if len(txt)==1:
        try: return json.loads(txt[0])
        except ValueError: return txt[0]
    return txt

def eval_app(script, arg=None):
    import websocket
    pages=json.load(urllib.request.urlopen('http://127.0.0.1:19241/json/list'))
    page=next(x for x in pages if 'app.xhtml' in x['url'])
    ws=websocket.create_connection(page['webSocketDebuggerUrl'],suppress_origin=True,timeout=240)
    ws.send(json.dumps({'id':1,'method':'Runtime.evaluate','params':{'expression':'('+script+')('+json.dumps(arg,ensure_ascii=False)+')','awaitPromise':True,'returnByValue':True}}))
    while True:
        r=json.loads(ws.recv())
        if r.get('id')==1:
            ws.close()
            if 'exceptionDetails' in r.get('result',{}): raise RuntimeError(r['result']['exceptionDetails'])
            return r.get('result',{}).get('result',{}).get('value')

if __name__=='__main__':
    if sys.argv[1]=='eval': print(json.dumps(eval_app(sys.argv[2]),ensure_ascii=False,indent=2))
    else: print(json.dumps(call(sys.argv[1], json.loads(sys.argv[2]) if len(sys.argv)>2 else {}), ensure_ascii=False,indent=2))
