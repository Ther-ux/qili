"""Real browser inspection of screen geometry and essential interactive journeys."""
from pathlib import Path
import json, html, xml.etree.ElementTree as ET
from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'design.json').read_text(encoding='utf-8'))
keys={x['key'] for x in data};results=[]
ns={'p':'http://www.evolus.vn/Namespace/Pencil','s':'http://www.w3.org/2000/svg'}
for p in data:
    root=ET.parse(ROOT/'screens'/(p['key']+'.svg'))
    for g in root.findall('.//s:g[@p:def="Evolus.Common:ms-oval"]',ns):
        text=g.find('p:metadata/p:property[@name="textContent"]',ns)
        if text is not None and text.text:
            for f in g.findall('.//s:foreignObject',ns):
                assert float(f.get('width','0'))>0 and float(f.get('height','0'))>0,(p['key'],text.text)
for p in data:
    for l in p['links']:
        assert l['target'] in keys,(p['key'],l)
        assert l['x']>=0 and l['y']>=0 and l['x']+l['w']<=p['w']+1 and l['y']+l['h']<=p['h']+1,(p['key'],l)
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    page=browser.new_page(viewport={'width':1680,'height':1120},device_scale_factor=1)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto((ROOT/'index.html').as_uri());page.wait_for_function('window.QILI_PLAYER')
    def go(k):page.evaluate('(k)=>window.QILI_PLAYER.go(k)',k);page.wait_for_function("document.querySelector('#stage img').complete")
    def click(label):page.locator('#stage .hotspot').get_by_role('button',name=label,exact=True) if False else page.locator('#stage').get_by_role('button',name=label,exact=True).first.click()
    def current():return page.evaluate('window.QILI_PLAYER.current')
    for p in data:
        go(p['key']);page.wait_for_timeout(45)
        assert page.locator('#stage img').evaluate('(img)=>img.naturalWidth>0'),p['key']
        page.locator('#stage').screenshot(path=str(ROOT/'qa'/(p['key']+'.png')))
    go('home');click('继续练习  →');assert current()=='train';click('棋位 b2');assert current()=='selected';click('棋位 b7');assert current()=='success'
    results.append('自主训练：首页 → 选择红炮 → 点击目标 → 独立完成')
    go('train');click('给我一点提示');assert current()=='hint1';click('给我一点提示');assert current()=='hint2';click('给我一点提示');assert current()=='hint3';click('完成这一步');assert current()=='assisted'
    results.append('三级提示递进，最终计提示后完成')
    go('train');click('棋位 b2');click('棋位 b6');assert current()=='illegal'
    results.append('非法落点反馈可达')
    go('report');page.get_by_role('textbox',name='reply',exact=True).fill('两枚棋子就不能吃过去');click('发送');assert current()=='followup';click('从当前局面开始摆谱');assert current()=='study';click('选择黑将 e9');assert current()=='study-selected';click('黑将 e9 → d9');assert current()=='study-moved';click('AI 分析当前局面');assert current()=='study-report'
    results.append('Agent：自述 → 追问 → 摆谱 → 合法分支 → 当前局面分析')
    go('import');click('选择示例图片');assert current()=='import-crop';click('裁剪识别＋字形复核');assert current()=='import-confirm';click('请先完成人工确认');assert current()=='import-confirm';click('切换人工确认');assert current()=='import-ready';click('确认棋盘，分析局面');assert current()=='import-result'
    results.append('图片导入：校准 → 核对 → 人工确认门槛 → 分析')
    go('replay');click('◀ 走前');assert current()=='replay-before';click('走后 ▶');assert current()=='replay'
    results.append('走前与走后始终留在解法回放')
    go('admin');click('维护训练题库');assert current()=='puzzles-admin';page.locator('#stage').get_by_role('button',name='编辑',exact=True).first.click();assert current()=='puzzle-edit';click('运行规则核验');assert current()=='publish';click('确认发布');assert current()=='published'
    results.append('后台：题库 → 编辑 → 核验 → 发布 → 完成')
    go('logs');page.locator('#stage').get_by_role('button',name='审查',exact=True).first.click();assert current()=='log-detail';click('查看用户侧提醒');assert current()=='warning'
    results.append('后台 Agent 审查可追踪到用户提醒')
    go('agent-wait');click('失败');assert current()=='failure';click('手动重试讲解');assert current()=='agent-wait'
    results.append('模型失败保留局面，可手动重试')
    go('mobile-home');click('开始练习 →');assert current()=='mobile-train';click('我走好了，和教练复盘');assert current()=='mobile-coach'
    results.append('移动端三屏主任务链路')
    assert not errors,errors
    browser.close()
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',17)
for start in range(0,len(data),12):
    sheet=Image.new('RGB',(1600,1092),'#E7ECE4');draw=ImageDraw.Draw(sheet)
    for j,p in enumerate(data[start:start+12]):
        im=Image.open(ROOT/'qa'/(p['key']+'.png')).convert('RGB');im.thumbnail((376,303))
        x=12+(j%4)*398;y=12+(j//4)*360;sheet.paste(im,(x+(376-im.width)//2,y));draw.text((x,y+315),p['title'],font=font,fill='#203C36')
    sheet.save(ROOT/'qa'/('contact-'+str(start//12+1)+'.png'))
report={'pages':len(data),'nativePrimitiveNodes':sum(len(x['nodes']) for x in data),'clickableHotspots':sum(len(x['links']) for x in data),'verifiedJourneys':results,'pageErrors':errors,'artifacts':'Native Pencil reopen/export evidence is recorded separately.'}
(ROOT/'qa'/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
