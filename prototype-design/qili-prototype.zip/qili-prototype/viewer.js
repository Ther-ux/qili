/* Offline prototype player for the screens authored in Evolus Pencil. */
(() => {
 'use strict';
 const pages=window.QILI_PAGES, byKey=Object.fromEntries(pages.map(p=>[p.key,p]));
 const $=s=>document.querySelector(s), stage=$('#stage'), stack=[];
 let current, showHotspots=false, toastTimer, filter='全部', query='';
 const state={assisted:false,confirmed:false,forms:{},profile:{},note:''};
 for(const group of ['设计说明','用户端','管理端','移动端']) {
  const h=document.createElement('h3');h.textContent=group;$('#pages').append(h);
  for(const p of pages.filter(p=>p.section===group)) {
   const b=document.createElement('button');b.textContent=p.title;b.dataset.page=p.key;b.onclick=()=>go(p.key);$('#pages').append(b);
  }
 }
 function toast(text){clearTimeout(toastTimer);$('#toast').textContent=text;$('#toast').classList.add('visible');toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),3500)}
 function go(key,back=false) {
  if(!byKey[key])return;
  if(current&&!back&&current.key!==key)stack.push(current.key);
  if(key==='train'){state.assisted=false;state.note=''}
  if(['hint1','hint2','hint3','replay'].includes(key))state.assisted=true;
  if(key==='success'&&state.assisted)key='assisted';
  location.hash=key;
  render(byKey[key]);
 }
 function place(el,r){Object.assign(el.style,{left:r.x+'px',top:r.y+'px',width:r.w+'px',height:r.h+'px'})}
 function overlay(r,text,cls='state-text') {const d=document.createElement('div');d.className=cls;place(d,r);d.textContent=text;stage.append(d);return d}
 function resize(){if(!current)return;const max=($('#main').clientWidth-44);let scale=Math.min(1,max/current.w);if(current.w<600)scale=Math.min(1,(window.innerHeight-160)/current.h,max/current.w);stage.style.transform=`scale(${scale})`;$('#stage-wrap').style.width=current.w*scale+'px';$('#stage-wrap').style.height=current.h*scale+'px'}
 function render(p) {
  current=p;stage.innerHTML='';stage.style.width=p.w+'px';stage.style.height=p.h+'px';stage.classList.toggle('show-hotspots',showHotspots);
  const img=new Image();img.src='screens/'+p.key+'.svg';img.alt=p.title;stage.append(img);
  for(const l of p.links){const b=document.createElement('button');b.className='hotspot';b.setAttribute('aria-label',l.label);b.title=l.label;place(b,l);b.onclick=()=>activate(l,b);stage.append(b)}
  for(const f of p.fields){const input=document.createElement('input');input.className='field';input.type=f.kind==='password'?'password':'text';input.placeholder=f.placeholder;input.setAttribute('aria-label',f.name);input.autocomplete='off';input.spellcheck=false;place(input,f);if(f.name!=='api-key')input.value=state.forms[f.name]||'';input.maxLength=f.name.includes('plan')?240:500;input.oninput=()=>{if(f.name==='api-key')return;state.forms[f.name]=input.value;if(f.name==='search'){query=input.value;updateFilter()}};stage.append(input)}
  document.title=p.title+' · 棋理学伴原型';$('#title').textContent=p.title;
  document.querySelectorAll('[data-page]').forEach(x=>x.classList.toggle('active',x.dataset.page===p.key));
  $('#note-title').textContent=p.title;$('#note-text').textContent=p.note;$('#note-rules').textContent=p.rules;
  $('#note-links').innerHTML='';const unique=p.links.filter((l,i,a)=>!l.label.startsWith('棋位 ')&&a.findIndex(x=>x.label===l.label)===i);
  for(const l of unique){const b=document.createElement('button');b.textContent=l.label||'跳转';b.onclick=()=>activate(l);$('#note-links').append(b)}
  resize();window.scrollTo(0,0);
 }
 function updateConfirmation(){stage.querySelectorAll('.confirm-state').forEach(x=>x.remove());const t=overlay({x:1034,y:684,w:340,h:58},(state.confirmed?'☑':'☐')+' 我已核对棋位与行棋方');t.classList.add('confirm-state');t.style.background='#eaf0e7';t.style.paddingLeft='14px';if(!state.confirmed){const m=overlay({x:1034,y:774,w:340,h:44},'请先确认棋盘');m.classList.add('confirm-state');Object.assign(m.style,{background:'#dce3da',color:'#79857b',justifyContent:'center',paddingLeft:'0'})}}
 function updateFilter(){
  stage.querySelectorAll('.muted-card,.filter-choice').forEach(x=>x.remove());if(current.key!=='library')return;
  stage.querySelectorAll('.hotspot').forEach(b=>b.style.pointerEvents='');
  const topics=['车','炮','马','相','兵','车'],titles=['沿线看远处','隔一子，才是炮','马腿在什么位置','看清象眼','过河以后，多一个方向','双车接力：两步收网'];
  for(let i=0;i<6;i++)if((filter!=='全部'&&topics[i]!==filter)||query&&!titles[i].includes(query)){
   const r={x:270+i%3*384,y:360+Math.floor(i/3)*263,w:360,h:241};overlay(r,'','muted-card');
   stage.querySelectorAll('.hotspot').forEach(b=>{if(parseFloat(b.style.top)>=r.y&&parseFloat(b.style.top)<r.y+r.h&&parseFloat(b.style.left)>=r.x&&parseFloat(b.style.left)<r.x+r.w)b.style.pointerEvents='none'});
  }
 }
 function activate(l,button) {
  const key=current.key, text=l.label||'';
  if(l.target!==key){
   if(key==='import-confirm'&&l.target==='import-ready')state.confirmed=true;
   if(key==='import-ready'&&l.target==='import-confirm')state.confirmed=false;
   if(key==='profile'&&text.includes('保存'))toast('学习偏好已应用到本次演示。');
   if(key==='report'&&l.target==='followup'&&!state.forms.reply){toast('先在输入框说说你的想法。');return}
   go(l.target);return;
  }
  if(key==='import-confirm'&&text.includes('人工确认')){toast('请先核对棋位与行棋方，并勾选人工确认。');return}
  if(key==='settings'){
   if(text.includes('清除')){const input=stage.querySelector('input[type=password]');if(input)input.value='';toast('已清除本次输入；原型从不保存密钥。');return}
   if(text.includes('测试')){const input=stage.querySelector('input[type=password]');if(!input?.value){toast('请用任意演示文本填写，勿输入真实 Key。');return}overlay({x:318,y:591,w:610,h:32},'连接成功（原型模拟，无网络调用）');toast('连接状态已模拟为成功，未发送请求。');return}
   if(text.includes('仅应用')){overlay({x:318,y:591,w:610,h:32},'设置已应用 · 尚未测试连接');toast('设置已应用，尚未测试连接。');return}
   toast('模型选择已用于本次演示。');return;
  }
  if(key==='profile'){stage.querySelectorAll('.selection').forEach(x=>{if(x.dataset.row===String(l.y))x.remove()});const d=overlay(l,'','selection');d.dataset.row=String(l.y);state.profile[l.y]=text;return}
  if(key==='library'&&text.startsWith('筛选 ')){filter=text.slice(3);updateFilter();toast('主题：'+filter+'。原型提供炮架任务的完整练习流程。');return}
  if(text.includes('导出')){const payload={prototype:true,source:'qili v0.3.0',page:current.key,notice:'此为原型示例记录，不是真实学习成绩'};const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));a.download='qili-prototype-sample.json';a.click();URL.revokeObjectURL(a.href);toast('已导出标注为原型示例的记录。');return}
  if(text==='翻转棋盘'){const im=stage.querySelector('img');im.style.transform=im.style.transform?'':'scaleX(-1)';toast('回放翻转示意；坐标定义保持不变。');return}
  if(key==='train'&&text.startsWith('棋位')){toast('请先点击红炮 b2，再点击目标黑车 b7。');return}
  toast('当前选项已选择；可使用“页面说明”查看此状态的交互规则。');
 }
 $('#back').onclick=()=>{const key=stack.pop();if(key)go(key,true)};
 $('#hot').onclick=()=>{showHotspots=!showHotspots;stage.classList.toggle('show-hotspots',showHotspots);$('#hot').classList.toggle('active',showHotspots)};
 $('#notes-toggle').onclick=()=>{$('#notes').hidden=!$('#notes').hidden;resize()};
 $('#full').onclick=()=>{document.body.classList.toggle('presentation');resize()};
 document.querySelectorAll('[data-goto]').forEach(b=>b.onclick=()=>go(b.dataset.goto));
 window.addEventListener('resize',resize);
 window.addEventListener('hashchange',()=>{const key=location.hash.slice(1);if(byKey[key]&&current?.key!==key)render(byKey[key])});
 document.addEventListener('keydown',e=>{if(e.target.matches('input'))return;if(e.key.toLowerCase()==='h')$('#hot').click();if(e.key==='ArrowLeft')$('#back').click()});
 window.QILI_PLAYER={go,get current(){return current.key},state};
 go(byKey[location.hash.slice(1)]?location.hash.slice(1):'guide');
})();
