@echo off
start "" "%~dp0qili-prototype.epgz"
